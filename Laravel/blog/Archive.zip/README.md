Live Demo: https://laravelblog.mostafaabdullhuq.com/
