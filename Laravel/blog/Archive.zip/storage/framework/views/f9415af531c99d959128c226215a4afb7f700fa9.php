<?php $__env->startSection('title'); ?>
    Create New Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    * {
    font-family: "Roboto", sans-serif;
    }

    body {
    background-color: #f5f5f5;
    width: 100vw;
    height: 100vh;
    }

    .container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 20px;
    flex-wrap: wrap;
    justify-content: flex-start;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    }

    .container .create-post {
    font-size: 20px;
    background-color: white;
    padding: 50px 30px;
    border-radius: 10px;
    max-width: 700px;
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 20px;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    -ms-border-radius: 10px;
    -o-border-radius: 10px;
    }

    .container .create-post * {
    border: none;
    outline: none;
    padding: 20px;
    background-color: #f7f7f7;
    border-radius: 5px;
    border: 1px solid #f1f1f1;
    }

    .container .create-post textarea {
    resize: none;
    height: 200px;
    }

    .container .create-post *::placeholder,
    .container .create-post *::-webkit-input-placeholder,
    .container .create-post select,
    .container .create-post select option {
    color: rgb(47, 47, 47);
    }

    .container .create-post button {
    background-color: #4b4b4b;
    color: white;
    cursor: pointer;
    transition: background-color 0.3s ease;
    -webkit-transition: background-color 0.3s ease;
    -moz-transition: background-color 0.3s ease;
    -ms-transition: background-color 0.3s ease;
    -o-transition: background-color 0.3s ease;
    }

    .container .create-post button:hover {
    background-color: #3a3a3a;
    }
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="create-post" method="POST" action="<?php echo e(route('posts.store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="text" name="title" placeholder="Post title" autofocus />
        <textarea name="description" placeholder="What's on your mind?"></textarea>
        <select class="creator" name="posted_by">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user['name']); ?>"><?php echo e($user['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit">Create Post</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mostafaabdullhuq/Desktop/ITI/Projects&Assignments/Laravel/blog/resources/views/posts/create.blade.php ENDPATH**/ ?>