<?php echo e($slot); ?>

<?php /**PATH /Users/mostafaabdullhuq/Desktop/ITI/Projects&Assignments/Laravel/blog/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>