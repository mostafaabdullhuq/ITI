<?php $__env->startSection('title'); ?>
    <?php if($post): ?>
        <?php echo e($post['title']); ?>

    <?php else: ?>
        Post not found
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    * {
    font-family: "Roboto", sans-serif;
    }

    body {
    background-color: #f5f5f5;
    }

    :root {
    --post-background: attr(data-img-src)
    }

    .container.my-container {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    justify-content: flex-start;
    flex-direction: column;
    
    max-width: 1200px;
    }

    .post,
    .post-creator {
    font-size: 20px;
    background-color: #fff;
    border: 1px solid #e5e5e5;
    border-radius: 3px;
    padding: 30px 30px 15px 30px;
    width: 100%;
    min-width: 400px;
    display: flex;
    flex-direction: column;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    }

    .title {
    margin-bottom: 0;
    word-break: break-word;
    }

    .post .description {
    color: rgb(79 79 79);
    word-break: break-word;
    }

    .post .post-info::after {
    content: "";
    display: block;
    width: 100%;
    height: 1px;
    background-color: #e5e5e5;
    margin-top: 10px;
    }

    .post .post-info,
    .post .last_update,
    .comment-info {
    font-size: 18px;
    margin: 5px 0px;
    }
    .comment-info {
    font-size: 1.2em
    }
    .controls {
    display: flex;
    gap: 10px;
    margin-top: 10px;
    }

    .controls input,
    .controls a {
    border: none;
    border-radius: 3px;
    padding: 10px 25px;
    background-color: crimson;
    color: white;
    text-decoration: none;
    transition: background-color 0.3s;
    -webkit-transition: background-color 0.3s;
    -moz-transition: background-color 0.3s;
    -ms-transition: background-color 0.3s;
    -o-transition: background-color 0.3s;
    -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
    -ms-border-radius: 3px;
    -o-border-radius: 3px;
    }

    .post .post-info,
    .post .last_update,
    .comment-info {
    position: relative;
    color: rgb(68, 68, 68);
    font-style: italic
    }

    .post .post-info span,
    .post .last_update span,
    .comment-info span {
    color: rgb(115, 115, 115);
    }



    .post .post-info .author-name {
    text-decoration: underline;
    cursor: pointer;
    }

    .post .post-info .author-name:hover {
    color: rgb(75, 75, 75);
    }

    .controls .view-comment {
    background-color: #455bd4;
    }

    .controls .edit-comment {
    background-color: #50b754;
    }

    .controls .delete-comment {
    background-color: #ee3b2e;
    }

    .controls .view-comment:hover {
    background-color: #313f91;
    }

    .controls .edit-comment:hover {
    background-color: #419643;
    }

    .controls .delete-comment:hover {
    background-color: #c4342a;
    }

    .new-comment form{
    display: flex;
    flex-direction: column
    }
    .new-comment form textarea {
    border: 1px solid #e5e5e5;
    border-radius: 3px;
    font-size: 20px;
    padding: 20px;
    outline: none;
    height: 200px;
    resize: none;
    }

    .new-comment form button {
    border: none;
    border-radius: 3px;
    padding: 15px 25px;
    background-color: rgb(68, 68, 68);
    color: white;

    }
    .new-comment form button:hover {
    background-color: rgb(75, 75, 75);
    }

    .new-comment .user-select {
    border: 1px solid #e5e5e5;
    padding: 15px;
    border-radius: 3px;
    outline: none;
    }
    .errornotification {
    display: flex;
    padding: 10px 20px !important;
    background-color: #CD0404 !important;
    color: white ;
    margin-top: 20px;
    border-radius: 3px;

    }

    .post-details {
    margin-left: 5px;
    }
    .sec-end::after {
    content: "";
    display: block;
    width: 100%;
    height: 1px;
    background-color: #e5e5e5;
    margin-top: 5px;
    }

    .post-details .publisher {
    position: relative;
    cursor: pointer;
    text-decoration: underline;
    }


    .post-details .publisher:hover::after {
    content: attr(data-email);
    position: absolute;
    top: 20px;
    left: -50%;
    padding: 10px 20px;
    background-color: black;
    color: white;
    border-radius: 3px;
    }

    

    <?php if($post->post_image): ?>
        .post-image {
        width: 100%;
        height: 500px;
        object-fit: cover;
        background: url('<?php echo e(Storage::url($post->post_image)); ?>');
        background-size: cover;
        background-repeat: no-repeat;
        border-radius: 3px;
        border: 1px solid #e5e5e5;
        }
    <?php endif; ?>
    .new-comment-submit {
    margin-top: 10px;
    }
    .create_date {
    text-transform: capitalize;
    }
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="title"><?php echo e($post->title); ?></h1>
    <div class="post-details sec-end">
        <span class="publisher fw-bold" data-email="<?php echo e($post->user->email); ?>"><?php echo e($post->user->name); ?></span>
        <br><span class="create_date fw-bold"><?php echo e($post->created_at); ?></span>
    </div>

    
    <?php if($post->post_image): ?>
        <div class="post-image">
        </div>
    <?php endif; ?>





    
    <div class="post">
        <?php if($post): ?>
            <p class="description sec-end"><?php echo e($post['description']); ?></p>
            <p class="last_update mt-0 ms-1">
                Last update on: <span
                    class="updated-at"><?php echo e($post->updated_at->format('jS \o\f F, Y g:i:s a')); ?></span><br><span
                    class="post-slug"><?php echo e($post->slug); ?></span>
            </p>
            
        <?php else: ?>
            <h4 class="mb-1">Post not found or has been deleted.</h4>
        <?php endif; ?>
    </div>
    <?php if($post): ?>
        
        
        <?php if(!$post->comments->isEmpty()): ?>
            <div class="accordion accordion-flush " id="accordionFlushExample">
                
                <?php $__currentLoopData = $post->comments->sortBy('updated_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-heading-<?php echo e($comment->id); ?>">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapse-<?php echo e($comment->id); ?>" aria-expanded="false"
                                aria-controls="flush-collapse-<?php echo e($comment->id); ?>">
                                <p class="comment-info">
                                    <span class="author-name"><?php echo e($comment->user->name); ?>

                                        (<?php echo e($comment->user->email); ?>)
                                    </span>
                                    &nbsp;at &nbsp;<span
                                        class="created-at"><?php echo e($comment->updated_at->format('jS \o\f F, Y g:i:s a')); ?></span>
                                </p>

                            </button>
                        </h2>
                        <div id="flush-collapse-<?php echo e($comment->id); ?>" class="accordion-collapse collapse py-2"
                            aria-labelledby="flush-heading-<?php echo e($comment->id); ?>" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body"><?php echo e($comment->comment); ?></div>
                            <div class="controls mb-3 d-flex justify-content-center align-items-center">
                                <a href="<?php echo e(route('comments.show', $comment->id)); ?>" class="view-comment ">Full Info</a>
                                <a href="<?php echo e(route('comments.edit', $comment->id)); ?>" class="edit-comment ">Edit</a>
                                <form action="<?php echo e(route('comments.destroy', $comment->id)); ?>" class="" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <input type="submit" value="Delete" class="delete-comment">
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        
        <div class="new-comment">
            <form method="POST" action="<?php echo e(route('comments.store', $post->id)); ?>">
                <?php echo csrf_field(); ?>
                <textarea name="comment" placeholder="Write an answer...">
<?php if($errors->any()): ?>
<?php echo e(old('comment')); ?>

<?php endif; ?>
</textarea>
                <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="errornotification">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button class="new-comment-submit mb-2">Add Comment</button>
            </form>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mostafaabdullhuq/Desktop/ITI/Projects&Assignments/Laravel/blog/resources/views/posts/show.blade.php ENDPATH**/ ?>