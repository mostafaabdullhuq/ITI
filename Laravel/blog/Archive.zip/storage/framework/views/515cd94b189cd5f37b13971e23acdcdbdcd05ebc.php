<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/mostafaabdullhuq/Desktop/ITI/Projects&Assignments/Laravel/blog/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>