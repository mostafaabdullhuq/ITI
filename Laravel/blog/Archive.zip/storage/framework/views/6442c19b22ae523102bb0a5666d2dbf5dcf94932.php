<?php $__env->startSection('title'); ?>
    Create New Comment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    * {
    font-family: "Roboto", sans-serif;
    }

    body {
    background-color: #f5f5f5;
    width: 100vw;
    height: 100vh;
    }

    .container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 20px;
    flex-wrap: wrap;
    justify-content: flex-start;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    }

    .container .create-comment {
    font-size: 20px;
    background-color: white;
    padding: 50px 30px;
    border-radius: 10px;
    max-width: 700px;
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 20px;
    -webkit-border-radius: 10px;
    -moz-border-radius: 10px;
    -ms-border-radius: 10px;
    -o-border-radius: 10px;
    }

    .container .create-comment * {
    border: none;
    outline: none;
    padding: 20px;
    background-color: #f7f7f7;
    border-radius: 5px;
    border: 1px solid #f1f1f1;
    }

    .container .create-comment textarea {
    resize: none;
    height: 200px;
    }

    .container .create-comment *::placeholder,
    .container .create-comment *::-webkit-input-placeholder,
    .container .create-comment select,
    .container .create-comment select option {
    color: rgb(47, 47, 47);
    }

    .container .create-comment button {
    background-color: #4b4b4b;
    color: white;
    cursor: pointer;
    transition: background-color 0.3s ease;
    -webkit-transition: background-color 0.3s ease;
    -moz-transition: background-color 0.3s ease;
    -ms-transition: background-color 0.3s ease;
    -o-transition: background-color 0.3s ease;
    }

    .container .create-comment button:hover {
    background-color: #3a3a3a;
    }
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="create-comment" method="POST" action="<?php echo e(route('comments.store', $post->id)); ?>">
        <?php echo csrf_field(); ?>
        <textarea name="comment" placeholder="What's on your mind?"></textarea>
        <select class="creator" name="commented_by">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit">Create Comment</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mostafaabdullhuq/Desktop/ITI/Projects&Assignments/Laravel/blog/resources/views/comments/create.blade.php ENDPATH**/ ?>